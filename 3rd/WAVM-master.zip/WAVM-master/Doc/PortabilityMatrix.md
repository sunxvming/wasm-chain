# Portability Matrix

| Key         |                                                   |
|-------------|---------------------------------------------------|
|:+1:         |Supported                                          |
|:question:   |Possibly works, but not tested                     |
|:shit:       |Only non-runtime components supported              |

|         |Windows         |Linux           |MacOS     |
|---------|----------------|----------------|----------|
| x86-64  |:+1:            |:+1:            |:+1:      |
| AArch64 |:+1::question:  |:+1:            |N/A       |
| x86-32  |:shit:          |:shit::question:|N/A       |
| ARM32   |:shit::question:|:shit::question:|N/A       |
